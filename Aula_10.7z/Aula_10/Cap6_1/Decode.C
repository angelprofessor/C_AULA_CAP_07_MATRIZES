/* Decode.C */
/* Decodifica arquivo codificado por Code.Exe */
/* para ser usado com redirecionamento */
#include <stdio.h> /* para getchar(), EOF */
#include <stdlib.h>

int main()				
{
	int ch;
	/* EOF � uma constante definida no arquivo stdio.h */
	while (( ch=getchar()) != EOF) /*pressione Ctrl+Z para terminar */
	{
		/* Converte para letras mai�sculas */
		printf("%c",(unsigned char) (ch - 1));
	}
	
	return 0;			
}
