/* Diag1.C */
/* Move o cursor na diagonal */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define C_DESCE "\x1B[B"

int main()
{
	printf("\x1B[2J");
	while(getche()!='.')
		printf(C_DESCE);
	system("pause");
	return 0;
}

