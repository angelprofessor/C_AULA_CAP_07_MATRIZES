/* PosCur.C */
/* Mostra posi��o do cursor */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define LIMPA printf("\x1B[2J")
#define POS_C(lin,col) printf("\x1B[%d;%df",lin,col)
#define APAG_L printf("\x1B[K")

int main()
{
	int lin=1,col=1;
	LIMPA;
	while(lin >=0)
	{
		POS_C(23,1);
		APAG_L;
		printf("Digite linha e coluna na forma 10,40 : ");
		scanf("%d,%d",&lin,&col);
		if(lin<0) break;
		POS_C(lin,col);
		printf("*(%d,%d)",lin,col);
	}
 	system("pause");
	return 0;
}
