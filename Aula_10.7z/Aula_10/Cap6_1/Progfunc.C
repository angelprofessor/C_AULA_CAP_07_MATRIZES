/* Progfunc.C */
/* Atribui um texto a tecla de fun�ao escolhida */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>	/* para getche() */

int main()				
{
	int tecla;
	printf("Entre o n�mero da tecla de fun��o que deseja programar: ");
	scanf("%d",&tecla);
	printf("\x1B[0;%d;\"%s\";13p",tecla+58,"dir *.c");

	system("PAUSE");	
	return 0;			
}
